# SDK field extraction preview

left_side and right_side are derived from the nearest boundary projections in drawing units. laneway_width is their mean sum across the candidate's points. These are geometric estimates, not surveyed width measurements. Missing or ambiguous sides remain null.

Before sending data to the cloud interface, review the geometry and confirm that the drawing unit is meters by setting drawing_unit_meters_confirmed to true in the reviewed JSON. This confirmation is not sent to the API. A different unit requires explicit conversion of every relevant coordinate and distance before integration; this plugin does not perform it.

Candidate identifiers, mine information, footage, radius, coal thickness, secondary side values and other unknown fields are not invented. The 5.9.1 cloud validation continues to require missing numerical fields and a formal unique lane code. The SDK import and cloud write have not been verified end to end. All candidates require professional review.
