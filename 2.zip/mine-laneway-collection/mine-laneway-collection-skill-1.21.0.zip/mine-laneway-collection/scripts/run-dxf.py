"""Load bundled wheels with the client's Python 3.12 for this invocation."""
import glob
from pathlib import Path
import platform
import runpy
import subprocess
import sys
import tempfile
import zipfile

if len(sys.argv) >= 3 and sys.argv[1] == '--run':
    sys.path.insert(0, sys.argv[2])
    script = str(Path(__file__).with_name('dxf_tools.py'))
    sys.argv = [script, *sys.argv[3:]]
    runpy.run_path(script, run_name='__main__')
    raise SystemExit(0)

if sys.version_info[:2] != (3, 12):
    raise SystemExit('Python 3.12 is required')
machine = platform.machine().lower()
if machine not in ('amd64', 'x86_64'):
    raise SystemExit('Bundled dependencies require an x64 processor')
if sys.platform == 'win32':
    tag = 'win_amd64'
else:
    raise SystemExit('Bundled dependencies support Windows x64; provide ezdxf separately for other platforms')
wheels = Path(__file__).resolve().parent.parent / 'vendor' / 'wheels'
patterns = [f'ezdxf-*-cp312-cp312-*{tag}*.whl', f'numpy-*-cp312-cp312-*{tag}*.whl', f'fonttools-*-cp312-cp312-*{tag}*.whl', 'pyparsing-*-py3-none-any.whl', 'typing_extensions-*-py3-none-any.whl']
with tempfile.TemporaryDirectory(prefix='mine-dxf-deps-') as site:
    for pattern in patterns:
        matches = glob.glob(str(wheels / pattern))
        if len(matches) != 1:
            raise SystemExit(f'Expected one bundled wheel matching {pattern}')
        with zipfile.ZipFile(matches[0]) as wheel:
            wheel.extractall(site)
    result = subprocess.run([sys.executable, __file__, '--run', site, *sys.argv[1:]], check=False)
    if result.returncode:
        raise SystemExit(result.returncode)
