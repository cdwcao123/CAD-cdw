import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const args = process.argv.slice(2)
if (!['inspect', 'draw', 'draw-points'].includes(args[0]) ||
    (args[0] === 'inspect' ? args.length !== 2 : args[0] === 'draw' ? ![3, 4].includes(args.length) : args.length !== 4)) {
  throw new Error('Usage: node dxf.mjs inspect input.dxf | draw lane-network.json new-output.dxf [reviewed-lanes.json] | draw-points lane-network.json new-output.dxf points.json')
}
const runtimeRoots = [process.env.RUNTIME_HOME, process.env.ELVESPUCK_INSTALLED_RUNTIME_HOME, process.env.ELVESPUCK_BUNDLED_RUNTIME_HOME].filter(Boolean)
const runtimeCandidates = process.platform === 'win32' ? runtimeRoots.map(root => [path.join(root, 'python', 'python.exe')]) : []
const candidates = process.env.MINE_DXF_PYTHON
  ? [[process.env.MINE_DXF_PYTHON]]
  : [...runtimeCandidates, ...(process.platform === 'win32' ? [['python'], ['python3'], ['py', '-3.12']] : [['python3.12'], ['python3'], ['python']])]
const python = candidates.find(([cmd, ...prefix]) => spawnSync(cmd, [...prefix, '-c', 'import sys;sys.exit(0 if sys.version_info[:2] == (3,12) else 1)'], { stdio: 'ignore', windowsHide: true }).status === 0)
if (!python) throw new Error('Python 3.12 not found. Set MINE_DXF_PYTHON to the client Python 3.12 executable.')
const [command, ...prefix] = python
const result = spawnSync(command, [...prefix, path.join(here, 'run-dxf.py'), ...args], { stdio: 'inherit', windowsHide: true, env: { ...process.env, PYTHONNOUSERSITE: '1', PYTHONDONTWRITEBYTECODE: '1' } })
if (result.error) throw result.error
process.exitCode = result.status ?? 1
