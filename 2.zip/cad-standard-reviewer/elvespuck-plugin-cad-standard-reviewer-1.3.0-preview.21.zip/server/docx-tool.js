import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { readZipEntries } from './zip.js'

export function extractDocxWithTool(bytes, python = process.env.CAD_REVIEW_DOCX_PYTHON || 'python') {
  try { readZipEntries(bytes) } catch { return Promise.resolve(null) }
  return new Promise(resolve => {
    const child = spawn(python, [fileURLToPath(new URL('./docx_extract.py', import.meta.url))], { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'], env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONDONTWRITEBYTECODE: '1' } })
    let output = '', done = false
    const finish = value => { if (done) return; done = true; clearTimeout(timer); resolve(value) }
    const timer = setTimeout(() => { child.kill(); finish(null) }, 30000)
    child.on('error', () => finish(null))
    child.stdin.on('error', () => {})
    child.stdout.on('data', chunk => { output += chunk.toString('utf8'); if (output.length > 4000000) { child.kill(); finish(null) } })
    child.on('close', code => {
      try {
        const result = JSON.parse(output)
        if (code || !Array.isArray(result.fragments)) throw new Error('invalid')
        finish({ fragments: result.fragments, reason: 'python-docx 提取正文、表格及独立页眉页脚；合并单元格、嵌套表格、图像、公式、修订和页码可能不完整，须人工核对。', parser: 'python-docx 1.2.0' })
      } catch { finish(null) }
    })
    child.stdin.end(bytes)
  })
}
