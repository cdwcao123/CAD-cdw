import io
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'vendor' / 'python'))
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph


def collect(container, section, fragments):
    table_no = 0
    paragraph_no = 0
    for block in container.iter_inner_content():
        if isinstance(block, Paragraph):
            paragraph_no += 1
            if block.text.strip():
                fragments.append({'location': {'type': 'docx-paragraph', 'section': section, 'paragraph': paragraph_no}, 'text': block.text})
        elif isinstance(block, Table):
            table_no += 1
            for row_no, row in enumerate(block.rows, 1):
                for cell_no, cell in enumerate(row.cells, 1):
                    text = '\n'.join(paragraph.text for paragraph in cell.paragraphs if paragraph.text.strip())
                    if text:
                        fragments.append({'location': {'type': 'docx-table', 'section': section, 'table': table_no, 'row': row_no, 'cell': cell_no}, 'text': text})


try:
    data = sys.stdin.buffer.read(20 * 1024 * 1024 + 1)
    if len(data) > 20 * 1024 * 1024:
        raise ValueError('file too large')
    doc = Document(io.BytesIO(data))
    fragments = []
    collect(doc, '正文', fragments)
    seen = set()
    for index, section in enumerate(doc.sections, 1):
        for name in ('header', 'first_page_header', 'even_page_header', 'footer', 'first_page_footer', 'even_page_footer'):
            part = getattr(section, name)
            if part.is_linked_to_previous:
                continue
            key = str(part.part.partname)
            if key not in seen:
                seen.add(key)
                collect(part, f'节{index} {name}', fragments)
    if len(fragments) > 10000 or sum(len(item['text']) for item in fragments) > 1000000:
        raise ValueError('extraction exceeds limit')
    print(json.dumps({'fragments': fragments}, ensure_ascii=False))
except Exception as error:
    print(json.dumps({'error': type(error).__name__}))
    sys.exit(1)
