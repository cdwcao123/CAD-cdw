import { spawn } from 'node:child_process'
import { mkdtemp, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { readZipEntries } from './zip.js'
import { existsSync } from 'node:fs'

function pythonPath() {
  if (process.env.CAD_REVIEW_OCR_PYTHON) return process.env.CAD_REVIEW_OCR_PYTHON
  const clientPython = process.env.USERPROFILE && join(process.env.USERPROFILE, '.local', 'share', 'elvespuck', 'runtime', 'dependencies', 'python-venv', '3.12', 'Scripts', 'python.exe')
  return clientPython && existsSync(clientPython) ? clientPython : 'python'
}

export async function recognizeDocument(bytes, kind) {
  if (process.platform !== 'win32') return { fragments: [], reason: 'Windows OCR 仅在 Windows 上可用。' }
  const dir = await mkdtemp(join(tmpdir(), 'cad-review-ocr-'))
  try {
    let input = join(dir, 'input.pdf'), names = []
    if (kind === 'pdf') await writeFile(input, bytes)
    else if (kind === 'docx') {
      input = dir
      const entries = readZipEntries(bytes)
      for (const [name, content] of entries) {
        if (!/^word\/media\/[^/]+\.(png|jpe?g|bmp|tiff?)$/i.test(name)) continue
        const local = `${String(names.length).padStart(4, '0')}.${name.split('.').at(-1).toLowerCase()}`
        names.push(name)
        await writeFile(join(dir, local), content)
      }
      if (!names.length) return { fragments: [], reason: 'DOCX 中没有可识别的 PNG、JPEG、BMP 或 TIFF 图片。' }
    } else throw new Error('unsupported OCR format')
    const result = await new Promise(resolve => {
      const child = spawn(pythonPath(), [fileURLToPath(new URL('./ocr.py', import.meta.url)), kind, input], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'], env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONDONTWRITEBYTECODE: '1' } })
      const chunks = []; let size = 0, done = false
      const finish = value => { if (!done) { done = true; clearTimeout(timer); resolve(value) } }
      const timer = setTimeout(() => { child.kill(); finish(null) }, 120000)
      child.on('error', () => finish(null))
      child.stdout.on('data', chunk => { size += chunk.length; if (size > 4000000) { child.kill(); finish(null) } else chunks.push(chunk) })
      child.on('close', code => { try { const value = JSON.parse(Buffer.concat(chunks).toString('utf8')); value.exitCode = code; finish(value) } catch { finish(null) } })
    })
    if (!result || !Array.isArray(result.results)) return { fragments: [], reason: 'Windows OCR 不可用或识别失败；请检查 Python 3.12、Windows 识别语言和文件。' }
    const fragments = result.results.filter(item => typeof item.text === 'string' && item.text.trim()).map(item => ({ location: kind === 'pdf' ? { type: 'pdf-ocr', page: item.number } : { type: 'docx-image-ocr', image: names[Number.parseInt(item.name, 10)] || item.name }, text: item.text, method: 'ocr' }))
    const failures = result.results.filter(item => item.error).length
    return { fragments, reason: `Windows OCR（${result.language}）：处理 ${result.results.length}/${result.total} 页或图片，${failures} 个失败；最多处理 20 项，识别可能有误或遗漏，须核对原件。${result.exitCode ? 'OCR 进程退出异常，结果仅供预览。' : ''}` }
  } catch { return { fragments: [], reason: 'OCR 输入无法读取或文件超出安全限制。' } }
  finally { await rm(dir, { recursive: true, force: true }) }
}
