import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'vendor' / 'python-ocr'))

async def main(kind, path):
    from winrt.windows.data.pdf import PdfDocument
    from winrt.windows.graphics.imaging import BitmapDecoder
    from winrt.windows.media.ocr import OcrEngine
    from winrt.windows.storage import FileAccessMode, StorageFile
    from winrt.windows.storage.streams import InMemoryRandomAccessStream

    engine = OcrEngine.try_create_from_user_profile_languages()
    if engine is None:
        raise RuntimeError('Windows OCR language unavailable')
    results = []

    async def recognize(stream):
        decoder = await BitmapDecoder.create_async(stream)
        bitmap = await decoder.get_software_bitmap_async()
        try:
            return (await engine.recognize_async(bitmap)).text
        finally:
            bitmap.close()

    if kind == 'pdf':
        file = await StorageFile.get_file_from_path_async(path)
        pdf = await PdfDocument.load_from_file_async(file)
        total = pdf.page_count
        for index in range(min(total, 20)):
            try:
                page = pdf.get_page(index)
                stream = InMemoryRandomAccessStream()
                try:
                    await page.render_to_stream_async(stream)
                    stream.seek(0)
                    results.append({'number': index + 1, 'text': await recognize(stream)})
                finally:
                    stream.close()
                    page.close()
            except Exception:
                results.append({'number': index + 1, 'error': 'page OCR failed'})
    elif kind == 'docx':
        files = sorted(Path(path).iterdir())
        total = len(files)
        for item in files[:20]:
            try:
                file = await StorageFile.get_file_from_path_async(str(item))
                stream = await file.open_async(FileAccessMode.READ)
                try:
                    results.append({'name': item.name, 'text': await recognize(stream)})
                finally:
                    stream.close()
            except Exception:
                results.append({'name': item.name, 'error': 'image OCR failed'})
    else:
        raise ValueError('unsupported format')
    return {'results': results, 'total': total, 'language': engine.recognizer_language.language_tag}

try:
    result = asyncio.run(main(sys.argv[1], sys.argv[2]))
    print(json.dumps(result, ensure_ascii=False), flush=True)
    # WinRT projection shutdown may crash during interpreter finalization.
    os._exit(0)
except Exception as error:
    print(json.dumps({'error': str(error)}, ensure_ascii=False))
    sys.exit(1)
