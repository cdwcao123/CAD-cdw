# CAD 图样标准化审查

本插件使用用户上传的规则和可选标准库审查 DXF/DWG 图纸。规则与标准库都支持正文查看、人工编辑版本和集合快照固定；模型不可用时保留解析器结果。

支持 JSON、YAML、CSV、TXT、Markdown、XML、HTML、RTF、PDF、DOCX 和 XLSX。复杂表格、扫描件、图片及公式可能提取不完整，结果需要人工核对。

安装与操作见《使用指南.md》。DWG 运行资产及许可义务见 `assets/dwg/README.md`。
