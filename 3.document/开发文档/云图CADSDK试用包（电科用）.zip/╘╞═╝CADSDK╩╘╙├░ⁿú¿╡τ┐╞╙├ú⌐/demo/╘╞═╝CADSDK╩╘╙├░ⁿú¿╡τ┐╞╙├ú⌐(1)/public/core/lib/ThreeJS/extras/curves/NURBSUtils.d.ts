import { Vector4 } from '../../Three.js';


export function findSpan( p: number, u: number, U: number[]): number;
export function calcBasisFunctions(span: number, u: number, p: number, U: number[]): number[];
export function calcBSplinePoint(p: number, U: number[], P: Vector4[], u: number): Vector4;
export function calcBasisFunctionDerivatives(span: number, u: number, p: number, n: number, U: number[] ): number[][];
export function calcBSplineDerivatives(p: number, U: number[], P: Vector4[], u: number, nd: number): Vector4[];
export function calcKoverI(k: number, i: number): number;
export function calcRationalCurveDerivatives(Pders: Vector4[]): Vector4[];
export function calcNURBSDerivatives(p: number, U: number[], P: Vector4[], u: number, nd: number): Vector4[];
