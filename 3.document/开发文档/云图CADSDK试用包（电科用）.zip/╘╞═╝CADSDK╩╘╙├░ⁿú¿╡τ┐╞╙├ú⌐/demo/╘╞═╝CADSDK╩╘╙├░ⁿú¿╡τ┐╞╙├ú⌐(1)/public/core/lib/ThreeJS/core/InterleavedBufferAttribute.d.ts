import { BufferAttribute } from './BufferAttribute';
import { InterleavedBuffer } from './InterleavedBuffer';
import { Matrix4 } from './../math/Matrix4';
import { Matrix } from './../math/Matrix3';

export class InterleavedBufferAttribute {
    
    constructor(interleavedBuffer: InterleavedBuffer, itemSize: number, offset: number, normalized?: boolean);

    
    name: string;

    
    data: InterleavedBuffer;

    
    itemSize: number;

    
    offset: number;

    
    normalized: boolean;

    
    get count(): number;

    
    get array(): ArrayLike<number>;

    
    set needsUpdate(value: boolean);

    
    readonly isInterleavedBufferAttribute: true;

    
    applyMatrix4(m: Matrix4): this;

    
    applyNormalMatrix(matrix: Matrix): this;

    
    transformDirection(matrix: Matrix): this;

    
    getX(index: number): number;

    
    setX(index: number, x: number): this;

    
    getY(index: number): number;

    
    setY(index: number, y: number): this;

    
    getZ(index: number): number;

    
    setZ(index: number, z: number): this;

    
    getW(index: number): number;

    
    setW(index: number, z: number): this;

    
    setXY(index: number, x: number, y: number): this;
    
    setXYZ(index: number, x: number, y: number, z: number): this;

    
    setXYZW(index: number, x: number, y: number, z: number, w: number): this;

    
    clone(data?: {}): BufferAttribute;

    
    toJSON(data?: {}): {
        isInterleavedBufferAttribute: true;
        itemSize: number;
        data: string;
        offset: number;
        normalized: boolean;
    };
}
